<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateTablesTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'TableID' => [
                'type' => 'INT',
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'RestaurantID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'Number' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'Capacity' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ]
        ]);

        $this->forge->addKey('TableID', TRUE);
        $this->forge->addForeignKey('RestaurantID', 'Restaurants', 'RestaurantID');
        $this->forge->createTable('Tables');
    }

    public function down()
    {
        $this->forge->dropTable('Tables');
    }
}
