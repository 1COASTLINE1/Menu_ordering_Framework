<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateRestaurantsTable extends Migration
{
    public function up()
    {
        // Define the Restaurants table
        $this->forge->addField([
            'RestaurantID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'Name' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'Address' => [
                'type' => 'TEXT',
            ],
            'PhoneNumber' => [
                'type' => 'VARCHAR',
                'constraint' => '50',
            ],
        ]);

        $this->forge->addKey('RestaurantID', TRUE); // Set RestaurantID as primary key
        $this->forge->createTable('Restaurants'); // Create the Restaurants table
    }

    public function down()
    {
        // Drop the Restaurants table if needed
        $this->forge->dropTable('Restaurants');
    }
}
