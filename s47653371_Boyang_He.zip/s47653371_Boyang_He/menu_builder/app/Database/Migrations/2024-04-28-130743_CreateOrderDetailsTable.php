<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateOrderDetailsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'DetailID' => [
                'type' => 'INT',
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'OrderID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'ItemID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'Quantity' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
        ]);

        $this->forge->addKey('DetailID', TRUE);
        $this->forge->addForeignKey('OrderID', 'Orders', 'OrderID');
        $this->forge->addForeignKey('ItemID', 'MenuItems', 'ItemID');
        $this->forge->createTable('OrderDetails');
    }

    public function down()
    {
        $this->forge->dropTable('OrderDetails');
    }
}
