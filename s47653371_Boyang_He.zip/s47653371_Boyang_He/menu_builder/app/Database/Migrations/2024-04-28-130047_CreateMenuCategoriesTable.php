<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateMenuCategoriesTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'CategoryID' => [
                'type' => 'INT',
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'RestaurantID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'Name' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'Description' => [
                'type' => 'TEXT',
            ],
        ]);

        $this->forge->addKey('CategoryID', TRUE);
        $this->forge->addForeignKey('RestaurantID', 'Restaurants', 'RestaurantID');
        $this->forge->createTable('MenuCategories');
    }

    public function down()
    {
        $this->forge->dropTable('MenuCategories');
    }
}
