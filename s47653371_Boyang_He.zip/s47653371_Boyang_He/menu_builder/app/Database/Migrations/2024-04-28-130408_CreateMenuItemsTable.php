<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateMenuItemsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'ItemID' => [
                'type' => 'INT',
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'RestaurantID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'Name' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'CategoryID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'Price' => [
                'type' => 'FLOAT',
            ],
            'SpecialFlag' => [
                'type' => 'BOOLEAN',
            ]
        ]);

        $this->forge->addKey('ItemID', TRUE);
        $this->forge->addForeignKey('RestaurantID', 'Restaurants', 'RestaurantID');
        $this->forge->createTable('MenuItems');
    }

    public function down()
    {
        $this->forge->dropTable('MenuItems');
    }
}
