<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateOrdersTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'OrderID' => [
                'type' => 'INT',
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'RestaurantID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'CustomerID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'TableID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'Timestamp' => [
                'type' => 'DATETIME',
            ],
            'Status' => [
                'type' => 'VARCHAR',
                'constraint' => '50',
            ],
            'TotalPrice' => [
                'type' => 'FLOAT',
            ]
        ]);

        $this->forge->addKey('OrderID', TRUE);
        $this->forge->addForeignKey('RestaurantID', 'Restaurants', 'RestaurantID');
        $this->forge->addForeignKey('CustomerID', 'Users', 'UserID');
        $this->forge->addForeignKey('TableID', 'Tables', 'TableID');
        $this->forge->createTable('Orders');
    }

    public function down()
    {
        $this->forge->dropTable('Orders');
    }
}
