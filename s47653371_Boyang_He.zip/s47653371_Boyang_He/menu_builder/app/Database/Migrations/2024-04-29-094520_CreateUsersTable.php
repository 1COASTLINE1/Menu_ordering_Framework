<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateUsersTable extends Migration
{
    public function up()
    {
        // Define the Users table
        $this->forge->addField([
            'UserID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'Name' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'Email' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'unique' => TRUE, // Assuming you want the email to be unique
            ],
            'UserType' => [
                'type' => 'ENUM',
                'constraint' => ['Customer', 'Staff'],
            ],
            'RestaurantID' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => TRUE,
                'null' => TRUE, // Allow NULL values
            ],
            'Password' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ]
        ]);

        $this->forge->addKey('UserID', TRUE); // Set UserID as primary key
        // Create foreign key only if the table Restaurants and field RestaurantID exists
        $this->forge->addForeignKey('RestaurantID', 'Restaurants', 'RestaurantID', 'CASCADE', 'CASCADE');
        $this->forge->createTable('Users'); // Create the Users table
    }

    public function down()
    {
        // Drop the Users table if needed
        $this->forge->dropTable('Users');
    }
}
