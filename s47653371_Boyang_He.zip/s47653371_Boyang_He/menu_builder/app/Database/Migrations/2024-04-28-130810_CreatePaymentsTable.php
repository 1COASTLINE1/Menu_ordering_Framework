<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePaymentsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'PaymentID' => [
                'type' => 'INT',
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'OrderID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'Method' => [
                'type' => 'VARCHAR',
                'constraint' => '50',
            ],
            'Status' => [
                'type' => 'VARCHAR',
                'constraint' => '50',
            ],
            'Amount' => [
                'type' => 'FLOAT',
            ],
        ]);

        $this->forge->addKey('PaymentID', TRUE);
        $this->forge->addForeignKey('OrderID', 'Orders', 'OrderID');
        $this->forge->createTable('Payments');
    }

    public function down()
    {
        $this->forge->dropTable('Payments');
    }
}
