<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateQRCodesTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'QRCodeID' => [
                'type' => 'INT',
                'unsigned' => TRUE,
                'auto_increment' => TRUE
            ],
            'RestaurantID' => [
                'type' => 'INT',
                'unsigned' => TRUE
            ],
            'TableID' => [
                'type' => 'INT',
                'unsigned' => TRUE,
                'null' => FALSE
            ],
            'CodeData' => [
                'type' => 'TEXT',
                'null' => FALSE
            ],
        ]);

        $this->forge->addKey('QRCodeID', TRUE);
        $this->forge->addForeignKey('RestaurantID', 'Restaurants', 'RestaurantID');
        $this->forge->addForeignKey('TableID', 'Tables', 'TableID');
        $this->forge->createTable('QRCodes');
    }

    public function down()
    {
        $this->forge->dropTable('QRCodes');
    }
}
