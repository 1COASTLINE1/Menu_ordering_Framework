<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->GET('/', 'MenuController::index');
$routes->GET('/Log_In', 'MenuController::Log_In');
$routes->GET('/Menu_Page', 'EditMenuController::index');
$routes->GET('/Management', 'DatabaseController::managementPage');
$routes->GET('/Sign_Up', 'MenuController::Sign_Up');

$routes->POST('auth/submit_registration', 'RegistrationController::submit_registration');


//Management page
$routes->group('admin', function($routes) {
    $routes->match(['GET', 'POST'], 'addedit', 'DatabaseController::addedit');
    $routes->match(['GET', 'POST'], 'addedit/(:num)', 'DatabaseController::addedit/$1');
    $routes->GET('delete/(:num)', 'DatabaseController::delete/$1');

});

$routes->match(['GET', 'POST'], 'admin/manageData/(:any)/(:segment)', 'DatabaseController::manageData/$1/$2');
$routes->GET('admin/deleteData/(:any)/(:num)', 'DatabaseController::deleteData/$1/$2');


//LogIN 
$routes->POST('/login/submit_login', 'LogInController::submit_login');


//Add menu
$routes->GET('/upload', 'MenuController::AddMenu');
$routes->POST('/upload', 'Setup_MenuController::upload');
$routes->POST('/add-category', 'Setup_MenuController::addCategory');
$routes->POST('/add-menu-item', 'Setup_MenuController::addMenuItem');


//QRCode 
$routes->GET('/QR_Generator', 'MenuController::QR_Generator');
$routes->POST('/generate_tables_and_qrcodes', 'QRCode_OrderController::generateTablesAndQRCodes');


//Menu
$routes->POST('/order/process', 'EditMenuController::processOrder');
