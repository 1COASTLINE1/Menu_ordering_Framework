<?php namespace App\Controllers;

use App\Models\Users;
use App\Models\Restaurants;
use App\Models\Tables;
use CodeIgniter\Controller;

class RegistrationController extends BaseController
{
    public function submit_registration()
    {
        $role = $this->request->getPost('role');

        if ($role == 'Customer') {
            $userModel = new Users();  
            $data = [
                'Email' => $this->request->getPost('email'),
                'Name' => $this->request->getPost('username'),
                'Password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
                'UserType' => 'Customer'  // Assume the type to be customer
            ];
            $userModel->save($data);
        } elseif ($role == 'Staff') {
            $userModel = new Users();  
            $data = [
                'Email' => $this->request->getPost('email'),
                'Name' => $this->request->getPost('username'),
                'Password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
                'UserType' => 'Staff'  
            ];
            $userModel->save($data);
        }elseif ($role == 'Table'){
            $userModel = new Tables();  
            $data = [
                'RestaurantID' => $this->request->getPost('restaurantID'),
                'Number' => $this->request->getPost('tablenumber'),
                'Capacity' => $this->request->getPost('tableCapacity'),
            ];
            $userModel->save($data);
        }else{
            $restaurantModel = new Restaurants();  
            $data = [
                'Name' => $this->request->getPost('restaurantName'),
                'Address' => $this->request->getPost('address'),
                'PhoneNumber' => $this->request->getPost('phone')
            ];
            $restaurantModel->save($data);
        }

        return redirect()->to(base_url('/Menu_Page'));  // redirect to
    }

}
