<?php

namespace App\Controllers;
use App\Models\MenuCategories;
use App\Models\MenuItems;
use CodeIgniter\Controller;

class Setup_MenuController extends Controller
{
    public function __construct()
    {
        // Load the URL helper, it will be useful in the next steps
        // Adding this within the __construct() function will make it 
        // available to all views
        helper('url');
        $this->session = session();
    

    }

    public function upload()
    {
        $file = $this->request->getFile('file');
    
        if ($file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $targetPath = FCPATH . 'photoes/';
            log_message('debug', 'FCPATH value: ' . FCPATH);
            if (!is_dir($targetPath)) {
                mkdir($targetPath, 0777, true);
            }
    
            if ($file->move($targetPath, $newName)) {
                //remove the file to new address
                $filePath = '/photoes/' . $newName;
                session()->set('uploaded_file_path', $filePath);
                
                return $this->response->setJSON(['success' => true, 'filename' => $newName, 'path' => $filePath]);
            } else {
                return $this->response->setJSON(['success' => false, 'message' => 'File could not be moved']);
            }
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Invalid file or file already moved']);
        }
    }
    
    public function addCategory()
    {
        $restaurantId = $this->request->getPost('restaurantId');
        $foodType = $this->request->getPost('foodType');

        $data = [
            'RestaurantID' => $restaurantId,
            'FoodType' => $foodType
        ];

        $categoryModel = new MenuCategories();
        if ($categoryModel->insert($data)) {
            // Redirect with success message
            return redirect()->to('/Management')->with('message', 'Category added successfully!');
        } else {
            // Redirect with error message
            return redirect()->to('/upload')->with('error', 'Failed to add category.');
        }
    }

    public function addMenuItem()
    {
        $restaurantId = $this->request->getPost('restaurantId');
        $categoryId = $this->request->getPost('categoryId');
        $foodName = $this->request->getPost('foodName');
        $price = $this->request->getPost('price');
        $filePath = session()->get('uploaded_file_path');
        
        $data = [
            'RestaurantID' => $restaurantId,
            'CategoryID' => $categoryId,
            'Name' => $foodName,
            'Price' => $price,
            'Photo_Address' => $filePath
        ];

        $menuItemModel = new MenuItems();
        if ($menuItemModel->insert($data)) {
            // Redirect with success message
            return redirect()->to('/Management')->with('message', 'Menu item added successfully!');
        } else {
            // Redirect with error message
            return redirect()->to('/upload')->with('error', 'Failed to add menu item.');
        }
    }





    
}

