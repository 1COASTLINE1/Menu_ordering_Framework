<?php namespace App\Controllers;


use App\Models\Tables;
use CodeIgniter\Controller;

class QRCode_OrderController extends BaseController
{   
    public function __construct()
    {
        helper(['url', 'form']);
        $this->tablesModel = new Tables();
        $this->session = \Config\Services::session();
    }
    
    public function generateTablesAndQRCodes() {
        log_message('debug', 'Starting table generation.');

        $restaurantId = $this->session->get('restaurant_id'); // get restaurant_id from session
        $numberOfTables = $this->request->getPost('numberOfTables'); 
    
        $qrCodes = [];
        for ($i = 1; $i <= $numberOfTables; $i++) {
            log_message('debug', 'Generating table ' . $i);
            if (!$restaurantId) {
                log_message('error', 'Invalid restaurant ID');
                return; // Add error handling
            }
            $tableId = $this->tablesModel->addNewTable($restaurantId, $i); 
            log_message('debug', 'Table ID: ' . $tableId . ', Table Number: ' . $i . ', Restaurant ID: ' . $restaurantId);
            $url = "https://infs3202-b5505a42.uqcloud.net/menu_builder/Menu_Page?restaurantId={$restaurantId}&tableId={$tableId}&tableNumber={$i}";

            $qrCodes[] = [
                'tableNumber' => $i,
                'qrCodeData' => $url 
            ];
        }
    
        $output = ['success' => true, 'qrCodes' => $qrCodes];
        log_message('info', 'Output: ' . print_r($output, true));  // This will log the output to your CI log file
        return $this->response->setJSON($output);
        
    }
    

    


}
    




