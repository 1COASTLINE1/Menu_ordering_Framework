<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Users;
class LogInController extends BaseController
{   
    public function __construct()
    {
        helper('url'); 

        $this->session = session();
    }

    public function submit_login()
    {
        $session = session();
        $model = new Users(); 
    
        $email = trim($this->request->getPost('email'));
        $password = $this->request->getPost('password');
    
        $user = $model->where('email', $email)->first();
    
        if ($user) {
            log_message('info', 'User found: ' . print_r($user, true));
            if (password_verify($password, $user['Password'])) {  // 确保这里使用正确的字段名
                log_message('info', 'Password verification successful.');
                $sessionData = [
                    'user_id' => $user['UserID'],
                    'user_type' => $user['UserType'],
                    'restaurant_id' => $user['RestaurantID'],  // 添加RestaurantID到会话
                    'logged_in' => TRUE
                ];
                $session->set($sessionData);
    
                return redirect()->to($user['UserType'] === 'Customer' ? '/Menu_Page' : '/Management');  
            } else {
                log_message('error', 'Password verification failed.');
            }
        } else {
            log_message('error', 'No user found for email: ' . $email);
        }
    
        $session->setFlashdata('error', 'Invalid email or password');
        return redirect()->to('Log_In');
    }
    
    

}