<?php namespace App\Controllers;

use App\Models\Users;
use App\Models\Restaurants;
use App\Models\Tables;
use App\Models\QRCodes;
use App\Models\MenuCategories;
use App\Models\MenuItems;
use App\Models\Orders;
use App\Models\OrderDetails;
use CodeIgniter\Controller;

class DatabaseController extends BaseController
{   
    public function __construct()
    {
        helper('url'); 

        $this->session = session();
    }


    public function managementPage()
    {   
        $menuCategoriesModel = new MenuCategories(); 
        $userModel = new Users(); 
        $restaurantModel = new Restaurants(); 
        $tableModel = new Tables(); 
        $QRCodeModel = new QRCodes(); 
        $menuitemModel = new MenuItems(); 
        $ordersModel = new Orders(); 
        $oderdetailsModel = new OrderDetails(); 


        $data['userDatas'] = $userModel->findAll();


        $data['restaurantDatas'] = $restaurantModel->findAll();
        

        $data['tableDatas'] = $tableModel->findAll();


        $data['QRCodeDatas'] = $QRCodeModel->findAll();


        $data['menuCategoriesDatas'] = $menuCategoriesModel->findAll();


        $data['menuitemDatas'] = $menuitemModel->findAll();


        $data['ordersDatas'] = $ordersModel->findAll();


        $data['orderdetailsDatas'] = $oderdetailsModel->findAll();

        // Define the colulmn name
        $data['userColumns'] = ['UserID', 'Name', 'Email', 'UserType', 'RestaurantID', 'Password'];
        $data['restaurantColumns'] = ['RestaurantID', 'Name', 'Address', 'PhoneNumber'];
        $data['tableColumns'] = ['TableID', 'RestaurantID', 'TableNumber', 'TableCapacity'];
        $data['QRCodeColumns'] = ['QRCodeID','RestaurantID','TableID','CodeData'];
        $data['menuCategoriesColumns'] = ['CategoryID','RestaurantID','FoodType'];
        $data['menuitemColumns'] = ['ItemID','RestaurantID','Name','CategoryID','Price','Photo_Address'];
        $data['ordersColumns'] = ['OrderID','RestaurantID','TableID','Timestamp','Status'];
        $data['orderdetailsColumns'] = ['DetailID','OrderID','ItemID','Quantity'];

        return view('Management_page', $data); 
    }

    // Method for User table
    public function addedit($id = null)
    {
        $model = new Users();
        if ($this->request->getMethod() === 'POST') {
            $data = $this->request->getPost();
    
            if ($id === null) {
                if ($model->insert($data)) {
                    $this->session->setFlashdata('success', 'User added successfully.');
                } else {
                    $this->session->setFlashdata('error', 'Failed to add user. Please try again.');
                }
            } else {
                if ($model->update($id, $data)) {
                    $this->session->setFlashdata('success', 'User updated successfully.');
                } else {
                    $this->session->setFlashdata('error', 'Failed to update user. Please try again.');
                }
            }
            return redirect()->to('/Management');
        }
    
        //deal with get 
        $data['user'] = $id === null ? null : $model->find($id);
        $db = \Config\Database::connect();
        $data['fields'] = $db->getFieldNames('Users');
        return view('addedit', $data);
    }
    
    public function delete($id)
    {
        $model = new Users();

        if ($model->delete($id)) {
            $this->session->setFlashdata('success', 'User deleted successfully.');
        } else {
            $this->session->setFlashdata('error', 'Failed to delete user.');
        }
        return redirect()->to('/Management');
    }



    public function manageData($modelPath, $id = null)
    {
        
        $this->session = session();
        $model = model($modelPath);
        $data['modelPath'] = $modelPath; 
        $data['primaryKey'] = $model->getPrimaryKey(); 
        $user_type= $this->session->get('user_type');

        if ($user_type=== 'Customer') {
            return redirect()->to('/Log_In');
        }

        // add the status of orders
        if ($modelPath === 'Orders') {
            $data['statuses'] = [
                'In process' => 'In process',
                'Completed' => 'Completed',
                'Cancelled' => 'Cancelled'
            ];
        }
    
        
        if ($this->request->getMethod() === 'POST') {
            $data = $this->request->getPost();
            
            if ($id === null) {
               
                if ($model->insert($data)) {
                    session()->setFlashdata('success', 'Entry added successfully.');
                } else {
                    session()->setFlashdata('error', 'Failed to add entry.');
                    $data['entry'] = $postData; 
                }
            } else {
                // update method
                if ($model->update($id, $data)) {
                    session()->setFlashdata('success', 'Entry updated successfully.');
                } else {
                    session()->setFlashdata('error', 'Failed to update entry.');
                    $data['entry'] = $postData; 
                }
            }
            return redirect()->to('/Management');
        }

       
        if ($id !== null) {
            $data['entry'] = $model->find($id);
        }
        $data['fields'] = $model->allowedFields; 
        return view('addedit', $data);
    }


    public function deleteData($modelPath, $id)
    {
        $model = model($modelPath);

        if ($model->delete($id)) {
            session()->setFlashdata('success', 'Entry deleted successfully.');
        } else {
            session()->setFlashdata('error', 'Failed to delete entry.');
        }
        return redirect()->to('/Management'); 
    }


    




}
    




