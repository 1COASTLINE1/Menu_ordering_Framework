<?php namespace App\Controllers;


use App\Models\MenuCategories;
use App\Models\MenuItems;
use App\Models\Orders;
use App\Models\OrderDetails;
use CodeIgniter\Controller;

class EditMenuController extends BaseController
{
    public function __construct()
    {
        helper('url'); 
        $this->session = session();
        $this->itemModel = new MenuItems();
        $this->categoryModel = new MenuCategories(); 
        $this->ordersModel = new Orders();
        $this->orderDetailsModel = new OrderDetails();
    }

    public function index()
    {
        $session = session();
        $restaurantID = $this->request->getGet('restaurantId') ?? $this->session->get('restaurant_id');
        $tableID = $this->request->getGet('tableId'); 
        log_message('info', 'Restaurant ID from session: ' . $restaurantID);
        log_message('info', 'Table ID URL QueryString: ' . $tableID);
        // Fetch categories specific to the restaurant
        $categories = $this->categoryModel->where('RestaurantID', $restaurantID)->findAll();
        log_message('debug', 'Fetched categories: ' . print_r($categories, true));
        foreach ($categories as &$category) {
            $category['items'] = $this->itemModel->where([
                'CategoryID' => $category['CategoryID'],
                'RestaurantID' => $restaurantID
            ])->findAll();
        }

        $data = [
            'title' => 'Menu Management',
            'menuCategories' => $categories,
            'categories' => $categories
        ];

        return view('/Menu_page', $data);
    }


    public function processOrder() {
        $session = session();
        $restaurantID = $this->request->getGet('restaurantId') ?? $this->session->get('restaurant_id');
        $tableID = $this->request->getGet('tableId'); // Retrieve 'tableId' from URL parameters
        log_message('info', 'Direct $_GET tableId: ' . $_GET['tableId']);
        log_message('info', 'Request object: ' . print_r($this->request->getVar(), true));

        $postData = json_decode($this->request->getBody(), true);

        $items = $postData['items'];
    
        // Prepare order data
        $orderData = [
            'RestaurantID' => $restaurantID,
            'TableID' => $tableID,
        ];
    
        // Create a new order
        $orderId = $this->ordersModel->insert($orderData);
    
        // Check if order was successfully created
        if (!$orderId) {
            return $this->response->setJSON(['success' => false, 'message' => 'Failed to create order']);
        }
        log_message('info', 'Order ID: ' . $orderId);
    
        // Insert order details
        foreach ($items as $item) {
            $detailData = [
                'OrderID' => $orderId,
                'ItemID' => $item['id'],
                'Quantity' => $item['quantity']
            ];
            $this->orderDetailsModel->save($detailData);
        }
    
        return $this->response->setJSON(['success' => true, 'message' => 'Order processed']);
    }
    


}