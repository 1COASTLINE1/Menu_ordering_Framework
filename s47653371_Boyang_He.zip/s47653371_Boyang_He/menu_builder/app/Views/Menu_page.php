<!-- MenuPage.php -->
<?= $this->extend('layout') ?>

<?= $this->section('pageCSS') ?>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('css/Menu_page.css'); ?>">
<?= $this->endSection() ?>

<?= $this->section('content') ?>


<div class="content-wrapper">
  <img src="<?= base_url("photoes/poster4.png"); ?>" alt="Promotional Poster" class="poster">
  <!-- Menu list -->
  <div class="btn-group menu-list">
    <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
        ALL
    </button>
    <ul class="dropdown-menu dropdown-menu-lg-end">
        <?php foreach ($menuCategories as $category): ?>
            <li><a class="dropdown-item" href="#<?= strtolower($category['FoodType']); ?>Section"><?= $category['FoodType']; ?></a></li>
        <?php endforeach; ?>
    </ul>
</div>


<?php foreach ($categories as $category): ?>
  <div id="<?= strtolower($category['FoodType']); ?>Section"> 
    <div class="row">
      <?php foreach ($category['items'] as $item): ?>
        <div id="item-<?= $item['ItemID']; ?>" class="col-md-4"> <!-- Ensure this ID is correctly set -->
          <img src="<?= base_url("" . $item['Photo_Address']); ?>" alt="Food Item" class="img-fluid">
          <h5><?= esc($item['Name']); ?></h5>
          <p>$ <?= esc($item['Price']); ?></p>
          <input type="number" min="1" value="1" id="quantity-<?= $item['ItemID']; ?>">
          <button class="btn btn-primary add-to-cart-btn" onclick="addToCart('<?= $item['ItemID']; ?>')">Add to Cart</button>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<?php endforeach; ?>






<!-- Shopping cart offcanvas -->
<div class="shopping-cart" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom" aria-controls="offcanvasBottom">
  <i class="fas fa-shopping-cart"></i>
</div>

<div class="offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasBottom" aria-labelledby="offcanvasBottomLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasBottomLabel">Your Cart</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body small">
    <ul class="list-group list-group-flush">
        <!-- Cart items will be added here dynamically -->
    </ul>
    <p id="totalPrice">Total: $0.00</p>
    <div class="d-grid gap-2">
    <button class="btn btn-primary" type="button" id="checkoutButton">Checkout</button>
  </div>
</div>

</div>

<?= $this->endSection() ?>

<?= $this->section('pageJS') ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  let cart = {
      items: [],
      addItem: function(item) {
          console.log("Adding item:", item);
          this.items.push(item);
          this.updateCartUI();
      },
      getTotalPrice: function() {
          let total = this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
          console.log("Calculating total price:", total);
          return total.toFixed(2);
      },
      updateCartUI: function() {
          console.log("Updating cart UI with items:", this.items);
          const cartList = document.querySelector('.list-group-flush');
          cartList.innerHTML = '';  // Clear current cart UI
          this.items.forEach((item, index) => {
              const itemHTML = `<li class="list-group-item d-flex justify-content-between align-items-center">
                                  ${item.name}
                                  <span>$${(item.price * item.quantity).toFixed(2)}</span>
                                  <button onclick="cart.removeItem(${index})" class="btn btn-danger btn-sm">Remove</button>
                                </li>`;
              cartList.innerHTML += itemHTML;
          });
          // Update total price
          document.querySelector('#totalPrice').textContent = `Total: $${this.getTotalPrice()}`;
      },
      removeItem: function(index) {
          console.log("Removing item at index:", index);
          this.items.splice(index, 1);
          this.updateCartUI();
      }
  };

  function addToCart(itemId) {
      console.log("Attempting to add to cart:", itemId);
      const quantity = parseInt(document.getElementById(`quantity-${itemId}`).value);
      const nameElement = document.querySelector(`#item-${itemId} h5`);
      const priceElement = document.querySelector(`#item-${itemId} p`);
      if (!nameElement || !priceElement) {
          console.error("Cannot find item elements on the page.");
          return;
      }
      const name = nameElement.textContent;
      const price = parseFloat(priceElement.textContent.replace('$', ''));
      
      console.log("Adding item with name:", name, "price:", price, "quantity:", quantity);

      cart.addItem({
          id: itemId,
          name: name,
          price: price,
          quantity: quantity
      });
  }

  document.getElementById('checkoutButton').addEventListener('click', function() {
    const cartItems = cart.items;
    if (cartItems.length === 0) {
        alert('No items in the cart');
        return;
    }


    // Prepare data to send
    const orderData = {
        items: cartItems
    };

    // Send data to server using AJAX
    $.ajax({
        url: '<?= base_url('order/process'); ?>',  // Ensure this URL is set up to handle POST in your CI routes
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(orderData),
        success: function(response) {
            console.log('Order processed:', response);
            // Handle any post-checkout logic here, such as clearing the cart
            if(response.success) {
                alert('Order successfully processed!');
                cart.items = []; // Clear cart
                cart.updateCartUI(); // Update UI
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error('Error processing order:', textStatus, errorThrown);
            alert('Failed to place order. Please try again.');
        }
    });
  });


</script>


<?= $this->endSection() ?>

