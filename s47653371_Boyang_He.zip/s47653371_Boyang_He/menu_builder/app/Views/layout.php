<!-- layout.php -->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $title ?? 'Management Page' ?></title>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<!-- Main CSS -->
<link rel="stylesheet" href="<?= base_url('css/Main_page.css'); ?>">

<!-- Section to include page-specific CSS -->
<?= $this->renderSection('pageCSS') ?>

</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Coffee Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="<?= base_url(); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Menu
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?= base_url('/Menu_Page'); ?>">Menu_list</a>
          <a class="dropdown-item" href="<?= base_url('/Management'); ?>">Management_page</a>
          <a class="dropdown-item" href="<?= base_url('/QR_Generator'); ?>">QR_CODE_GENERATOR</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Log_In'); ?>">Log In</a>
      </li>
    </ul>
  </div>
</nav>

<main>
    <?= $this->renderSection('content') ?> <!-- Placeholder for page content -->
</main>

<!-- Footer -->
<footer class="text-light bg-dark pt-4 pb-2">
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <h5>Contact Us</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-light">Our Address</a></li>
          <li><a href="#" class="text-light">Email Us</a></li>
          <li><a href="#" class="text-light">Phone</a></li>
        </ul>
      </div>
      <div class="col-sm-6">
        <h5>Follow Us</h5>
        <a href="#" class="text-light mr-2"><i class="fab fa-facebook"></i></a>
        <a href="#" class="text-light mr-2"><i class="fab fa-twitter"></i></a>
        <a href="#" class="text-light mr-2"><i class="fab fa-instagram"></i></a>
        <a href="#" class="text-light"><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
  </div>
</footer>

<!-- Bootstrap JS and its dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- Section to include page-specific JavaScript -->
<?= $this->renderSection('pageJS') ?>
</body>
</html>
