<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Bootstrap CSS -->
<title>Dropzone File Upload</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.2/min/dropzone.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.2/min/dropzone.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<!-- Main CSS -->
<link rel="stylesheet" href="<?= base_url('css/AddMenu.css'); ?>">

<!-- Warning Message -->
<?php if (session()->has('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?= session()->get('error') ?>
    </div>
<?php endif; ?>

<?php if (session()->has('message')): ?>
    <div class="alert alert-success" role="alert">
        <?= session()->get('message') ?>
    </div>
<?php endif; ?>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Coffee Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="<?= base_url(); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Menu
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?= base_url('/Menu_Page'); ?>">Menu_list</a>
          <a class="dropdown-item" href="<?= base_url('/Management'); ?>">Management_page</a>
          <a class="dropdown-item" href="<?= base_url('/QR_Generator'); ?>">QR_CODE_GENERATOR</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Log_In'); ?>">Log In</a>
      </li>
    </ul>
  </div>
</nav>

<body>
    <h2>Drop photoes for menu here.</h2>

    <form action="<?= base_url('upload'); ?>" class="dropzone" id="myDropzone">
        <?= csrf_field() ?>
    </form>
    <main class="form-signin w-100 m-auto">
      <div id="message" class="message"></div>
      
      <h4>Insert Category Information</h4>
      <form action="<?= base_url('/add-category') ?>" method="post">
        <div id="insertCategory">
              <div class="form-floating mb-3">          
                <label for="floatingInputEmail">RestaurantID</label>
                <input type="int" class="form-control" name="restaurantId" id="restaurantId" placeholder="Enter Restaurant ID">
              </div>
              <div class="form-floating mb-3">
                <label for="floatingInputUsername">FoodType</label>
                <input type="text" class="form-control" name="foodType" id="foodType" placeholder="Enter Food Type">
              </div>
              <button class="btn btn-primary w-100 py-2" type="submit">Confrim</button>
        </div>
      </form>

      <h4>Insert Menu Details Information</h4>
      <form action="<?= base_url('/add-menu-item') ?>" method="post">
        <div id="userFields">
            <div class="form-floating mb-3">
              <label for="floatingInputEmail">Restaurant ID</label>
              <input type="int" class="form-control" name="restaurantId" id="restaurantIdItem" placeholder="Enter Restaurant ID">
            </div>
            <div class="form-floating mb-3">
              <label for="floatingInputUsername">Category ID</label>
              <input type="int" class="form-control" name="categoryId" id="categoryId" placeholder="Enter Category ID">
            </div>
            <div class="form-floating mb-3">
              <label for="floatingPassword">Food Name</label>
              <input type="text" class="form-control" name="foodName" id="foodName" placeholder="Enter Food Name">
            </div>
            <div class="form-floating mb-3">
              <label for="floatingPassword">Price</label>
              <input type="int" class="form-control" name="price" id="price" placeholder="Password">
            </div>
            <button class="btn btn-primary w-100 py-2" type="submit">Confrim</button>
        </div>
      </form>
    </main>
      

<!-- I admit using ChatGpt to create the following codes to help me generate the follwing methods -->
<!-- Bootstrap JS and its dependencies -->
<script>
        Dropzone.options.myDropzone = {
            paramName: "file",
            maxFilesize: 4, // MB
            acceptedFiles: ".jpg,.jpeg,.png,.gif",
            init: function() {
                this.on("success", function(file, response) {
                    if (response.success) {
                        showMessage("File uploaded successfully!", "success");
                    } else {
                        showMessage("File upload failed!", "error");
                    }
                });
                this.on("error", function(file, errorMessage) {
                    showMessage("File upload error: " + errorMessage, "error");
                });
            }
        };

        function showMessage(message, type) {
            var messageElement = document.getElementById("message");
            messageElement.textContent = message;
            messageElement.className = "message" + type;
        }
    </script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>