<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Management_page</title>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Include Bootstrap Icons -->
    <!-- This link imports the Bootstrap Icons library, which provides a wide range of SVG icons for use in your projects. -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= base_url('css/Management.css'); ?>">

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Coffee Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="<?= base_url(); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Menu
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?= base_url('/Menu_Page'); ?>">Menu_list</a>
          <a class="dropdown-item" href="<?= base_url('/Management'); ?>">Management_page</a>
          <a class="dropdown-item" href="<?= base_url('/QR_Generator'); ?>">QR_CODE_GENERATOR</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Log_In'); ?>">Log In</a>
      </li>
    </ul>
  </div>
</nav>

<!-- I admit using ChatGpt creating these two models -->
<!-- Modal -->
<div class="modal fade" id="infoModal" tabindex="-1" aria-labelledby="infoModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="infoModalLabel">Important Information</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        In the registration interface that you will enter, you can select the type of account to create using the dropdown menu provided.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <a href="<?= base_url('/Sign_Up'); ?>" class="btn btn-primary">Proceed to Registration</a>
      </div>
    </div>
  </div>
</div>

<!-- Modal2 -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Quick Add Options</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <!-- ADD DATA -->
      <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
          <a href="<?= base_url('/Sign_Up'); ?>" class="nav-link link-dark" data-bs-toggle="modal" data-bs-target="#infoModal">Add User</a>
        </li>
        <li>
        <a href="<?= base_url('/Sign_Up'); ?>" class="nav-link link-dark" data-bs-toggle="modal" data-bs-target="#infoModal">Add Table</a>
        </li>
        <li>
          <a href="<?= base_url('/upload'); ?>" class="nav-link link-dark" >Add Menu</a>
        </li>
      </ul>
    </div>
  </div>
</div>

<!-- Main Section -->
<div class="content-wrapper">

  <div class="container-fluid mt-3">
    <div class="row mb-2">
      <div class="col">
        <input type="search" class="form-control" placeholder="Enter your search...">
      </div>
      <div class="col-auto">
        <button class="btn btn-primary">Search</button>
      </div>
      <!-- Button trigger modal -->
      <div class="col-auto">
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">
          Add Options
        </button>
      </div>
    </div>
  </div>
    



      <!-- User table -->
      <main class="container my-4">
        <h2>Users</h2>
        <table class="table">
          <thead>
            <tr>
              <!-- Dynamically create table headers based on the columns array -->
              <?php foreach ($userColumns as $column): ?>
                <th><?= $column; ?></th>
              <?php endforeach; ?>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <!-- Iterate over each data item in the 'datas' array -->
            <?php foreach ($userDatas as $data): ?>
            <tr>
              <!-- Iterate over each value in the data item -->
              <?php foreach ($data as $value): ?>
                <td><?= $value; ?></td>
              <?php endforeach; ?>
              <td>
                <!-- Action buttons for each row -->
                <a href="<?= base_url('admin/manageData/Users/' . $data['UserID']); ?>" class="btn btn-info btn-sm" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <a href="<?= base_url('admin/deleteData/Users/' . $data['UserID']); ?>" class="btn btn-warning btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                  <i class="fas fa-trash-alt"></i>
                </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </main>

      <!-- Restaurants table -->           
      <main class="container my-4">
        <h2>Restaurants</h2>
        <table class="table">
          <thead>
            <tr>
              <!-- Dynamically create table headers based on the columns array -->
              <?php foreach ($restaurantColumns as $column): ?>
                <th><?= $column; ?></th>
              <?php endforeach; ?>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <!-- Iterate over each data item in the 'datas' array -->
            <?php foreach ($restaurantDatas as $data): ?>
            <tr>
              <!-- Iterate over each value in the data item -->
              <?php foreach ($data as $value): ?>
                <td><?= $value; ?></td>
              <?php endforeach; ?>
              <td>
                <!-- Action buttons for each row -->
                <a href="<?= base_url('admin/manageData/Restaurants/' . $data['RestaurantID']); ?>" class="btn btn-info btn-sm" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <a href="<?= base_url('admin/deleteData/Restaurants/' . $data['RestaurantID']); ?>" class="btn btn-warning btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                  <i class="fas fa-trash-alt"></i>
                </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </main>
      
      <!-- Tables table -->   
      <main class="container my-4">
        <h2>Tables</h2>
        <table class="table">
          <thead>
            <tr>
              <!-- Dynamically create table headers based on the columns array -->
              <?php foreach ($tableColumns as $column): ?>
                <th><?= $column; ?></th>
              <?php endforeach; ?>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <!-- Iterate over each data item in the 'datas' array -->
            <?php foreach ($tableDatas as $data): ?>
            <tr>
              <!-- Iterate over each value in the data item -->
              <?php foreach ($data as $value): ?>
                <td><?= $value; ?></td>
              <?php endforeach; ?>
              <td>
                <!-- Action buttons for each row -->
                <a href="<?= base_url('admin/manageData/Tables/' . $data['TableID']); ?>" class="btn btn-info btn-sm" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <a href="<?= base_url('admin/deleteData/Tables/' . $data['TableID']); ?>" class="btn btn-warning btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                  <i class="fas fa-trash-alt"></i>
                </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </main>

      <!-- QRCodes table -->
      <main class="container my-4">
        <h2>QRCodes</h2>
        <table class="table">
          <thead>
            <tr>
              <!-- Dynamically create table headers based on the columns array -->
              <?php foreach ($QRCodeColumns as $column): ?>
                <th><?= $column; ?></th>
              <?php endforeach; ?>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <!-- Iterate over each data item in the 'datas' array -->
            <?php foreach ($QRCodeDatas as $data): ?>
            <tr>
              <!-- Iterate over each value in the data item -->
              <?php foreach ($data as $value): ?>
                <td><?= $value; ?></td>
              <?php endforeach; ?>
              <td>
                <!-- Action buttons for each row -->
                <a href="<?= base_url('admin/manageData/QRCodes/' . $data['QRCodeID']); ?>" class="btn btn-info btn-sm" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <a href="<?= base_url('admin/deleteData/QRCodes/' . $data['QRCodeID']); ?>" class="btn btn-warning btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                  <i class="fas fa-trash-alt"></i>
                </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </main>
      
      <!-- Menu Categories table -->
      <main class="container my-4">
          <h2>Menu Categories </h2>     
          <table class="table">
                <thead>
                  <tr>
                    <!-- Dynamically create table headers based on the columns array -->
                    <?php foreach ($menuCategoriesColumns as $column): ?>
                      <th><?= $column; ?></th>
                    <?php endforeach; ?>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <!-- Iterate over each data item in the 'datas' array -->
                  <?php foreach ($menuCategoriesDatas as $data): ?>
                  <tr>
                    <!-- Iterate over each value in the data item -->
                    <?php foreach ($data as $value): ?>
                      <td><?= $value; ?></td>
                    <?php endforeach; ?>
                    <td>
                      <!-- Action buttons for each row -->
                      <a href="<?= base_url('admin/manageData/MenuCategories/' . $data['CategoryID']); ?>" class="btn btn-info btn-sm" title="Edit">
                        <i class="fas fa-edit"></i>
                      </a>
                      <a href="<?= base_url('admin/deleteData/MenuCategories/' . $data['CategoryID']); ?>" class="btn btn-warning btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                        <i class="fas fa-trash-alt"></i>
                      </a>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
      </main>

      <!-- Menu Items table -->
        <main class="container my-4">
            <h2>Menu Items</h2>     
            <table class="table">
              <thead>
                <tr>
                  <!-- Dynamically create table headers based on the columns array -->
                  <?php foreach ($menuitemColumns as $column): ?>
                    <th><?= $column; ?></th>
                  <?php endforeach; ?>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <!-- Iterate over each data item in the 'datas' array -->
                <?php foreach ($menuitemDatas as $data): ?>
                <tr>
                  <!-- Iterate over each value in the data item -->
                  <?php foreach ($data as $value): ?>
                    <td><?= $value; ?></td>
                  <?php endforeach; ?>
                  <td>
                    <!-- Action buttons for each row -->
                    <a href="<?= base_url('admin/manageData/MenuItems/' . $data['ItemID']); ?>" class="btn btn-info btn-sm" title="Edit">
                      <i class="fas fa-edit"></i>
                    </a>
                    <a href="<?= base_url('admin/deleteData/MenuItems/' . $data['ItemID']); ?>" class="btn btn-warning btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                      <i class="fas fa-trash-alt"></i>
                    </a>
                    </div>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
        </main>

        <!-- Orders table -->
        <main class="container my-4">
          <h2>Orders</h2> 
          <table class="table">
            <thead>
              <tr>
                <!-- Dynamically create table headers based on the columns array -->
                <?php foreach ($ordersColumns as $column): ?>
                  <th><?= $column; ?></th>
                <?php endforeach; ?>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <!-- Iterate over each data item in the 'datas' array -->
              <?php foreach ($ordersDatas as $data): ?>
              <tr>
                <!-- Iterate over each value in the data item -->
                <?php foreach ($data as $value): ?>
                  <td><?= $value; ?></td>
                <?php endforeach; ?>
                <td>
                  <!-- Action buttons for each row -->
                  <a href="<?= base_url('admin/manageData/Orders/' . $data['OrderID']); ?>" class="btn btn-info btn-sm" title="Edit">
                    <i class="fas fa-edit"></i>
                  </a>
                  <a href="<?= base_url('admin/deleteData/Orders/' . $data['OrderID']); ?>" class="btn btn-warning btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                    <i class="fas fa-trash-alt"></i>
                  </a>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </main>

        <!-- Order Details table -->
        <main class="container my-4">
          <h2>Order Details</h2> 
          <table class="table">
            <thead>
              <tr>
                <!-- Dynamically create table headers based on the columns array -->
                <?php foreach ($orderdetailsColumns as $column): ?>
                  <th><?= $column; ?></th>
                <?php endforeach; ?>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <!-- Iterate over each data item in the 'datas' array -->
              <?php foreach ($orderdetailsDatas as $data): ?>
              <tr>
                <!-- Iterate over each value in the data item -->
                <?php foreach ($data as $value): ?>
                  <td><?= $value; ?></td>
                <?php endforeach; ?>
                <td>
                  <!-- Action buttons for each row -->
                  <a href="<?= base_url('admin/manageData/OrderDetails/' . $data['DetailID']); ?>" class="btn btn-info btn-sm" title="Edit">
                    <i class="fas fa-edit"></i>
                  </a>
                  <a href="<?= base_url('admin/deleteData/OrderDetails/' . $data['DetailID']); ?>" class="btn btn-warning btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                    <i class="fas fa-trash-alt"></i>
                  </a>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </main>
</div>

<!-- Footer -->
<footer class="text-light bg-dark pt-4 pb-2">
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <h5>Contact Us</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-light">Our Address</a></li>
          <li><a href="#" class="text-light">Email Us</a></li>
          <li><a href="#" class="text-light">Phone</a></li>
        </ul>
      </div>
      <div class="col-sm-6">
        <h5>Follow Us</h5>
        <a href="#" class="text-light mr-2"><i class="fab fa-facebook"></i></a>
        <a href="#" class="text-light mr-2"><i class="fab fa-twitter"></i></a>
        <a href="#" class="text-light mr-2"><i class="fab fa-instagram"></i></a>
        <a href="#" class="text-light"><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
  </div>
</footer>

<!-- Bootstrap JS and its dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Bootstrap JS (Ensure you are using the correct version) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


