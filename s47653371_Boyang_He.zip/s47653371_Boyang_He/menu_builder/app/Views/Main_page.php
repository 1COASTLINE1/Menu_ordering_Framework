<?= $this->extend('layout') ?>

<?= $this->section('content') ?>

<!-- Background image section with button -->
<div class="bg-image">
  <div class="text-center welcome-message">
    <h1>WELCOME!</h1>
    <p>CLICK THE BUTTON TO START YOUR ORDER</p>
  </div>
  <button class="btn btn-primary order-now-btn" onclick="window.location.href='<?= base_url('/Log_In'); ?>'">Order Now</button>
</div>



<!-- Main Content -->
<div class="main">
    <div class="container dish-container background-container"> 
  <div class="container dish-container"> 
    <div class="row">
      <div class="col-sm-4">
        <img src="photoes/food1.webp" class="img-fluid" alt="Dish 1">
        <h5>Dish Name 1</h5>
      </div>
      <div class="col-sm-4">
        <img src="photoes/food2.webp" class="img-fluid" alt="Dish 2">
        <h5>Dish Name 2</h5>
      </div>
      <div class="col-sm-4">
        <img src="photoes/food3.webp" class="img-fluid" alt="Dish 3">
        <h5>Dish Name 3</h5>
      </div>  
      </div>
    </div>
  </div>
</div>




<?= $this->endSection() ?>