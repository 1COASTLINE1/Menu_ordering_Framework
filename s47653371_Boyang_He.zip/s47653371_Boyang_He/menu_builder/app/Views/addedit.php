<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coffee Shop and Restaurant</title>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= base_url('css/Management.css'); ?>">
</head>
<body>
  
<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Coffee Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link " href="<?= base_url(); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Menu
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?= base_url('/Menu_Page'); ?>">Menu_list</a>
          <a class="dropdown-item active" href="<?= base_url('/Management'); ?>">Management_page</a>
          <a class="dropdown-item" href="<?= base_url('/QR_Generator'); ?>">QR_CODE_GENERATOR</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('Log_In'); ?>">Log In</a>
      </li>
    </ul>
  </div>
</nav>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <h2 class="text-center mb-4"><?= isset($entry) ? 'Edit ' . $modelPath : 'Add ' . $modelPath ?></h2>
                <form method="post" action="<?= base_url('admin/manageData/' . $modelPath . (isset($entry) ? '/' . $entry[$primaryKey] : '')); ?>">
                    <?php foreach ($fields as $field): ?>
                        <div class="mb-3">
                            <label for="<?= $field ?>" class="form-label"><?= ucwords(str_replace('_', ' ', $field)) ?></label>
                            <?php if ($field == 'Status' && isset($statuses)): ?>
                                  <select class="form-control" id="<?= $field ?>" name="<?= $field ?>">
                                      <?php foreach ($statuses as $key => $value): ?>
                                          <option value="<?= $key ?>" <?= isset($entry) && $entry[$field] == $key ? 'selected' : '' ?>><?= $value ?></option>
                                      <?php endforeach; ?>
                                  </select>
                            <?php else: ?>
                                  <input type="<?= $field === 'email' ? 'email' : 'text' ?>"
                                        class="form-control"
                                        id="<?= $field ?>"
                                        name="<?= $field ?>"
                                        value="<?= isset($entry) ? esc($entry[$field]) : '' ?>"
                                        required>
                              <?php endif; ?>

                        </div>
                    <?php endforeach; ?>
                    <button type="submit" class="btn btn-primary"><?= isset($entry) ? 'Update ' . $modelPath : 'Add ' . $modelPath ?></button>
                </form>
            </div>
        </div>
    </div>
</section>



<!-- Footer -->
<footer class="text-light bg-dark pt-4 pb-2">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <h5>Contact Us</h5>
              <ul class="list-unstyled">
                <li><a href="#" class="text-light">Our Address</a></li>
                <li><a href="#" class="text-light">Email Us</a></li>
                <li><a href="#" class="text-light">Phone</a></li>
              </ul>
            </div>
            <div class="col-sm-6">
              <h5>Follow Us</h5>
              <a href="#" class="text-light mr-2"><i class="fab fa-facebook"></i></a>
              <a href="#" class="text-light mr-2"><i class="fab fa-twitter"></i></a>
              <a href="#" class="text-light mr-2"><i class="fab fa-instagram"></i></a>
              <a href="#" class="text-light"><i class="fab fa-linkedin"></i></a>
            </div>
          </div>
        </div>
</footer>
      
 <!-- Bootstrap JS and its dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
