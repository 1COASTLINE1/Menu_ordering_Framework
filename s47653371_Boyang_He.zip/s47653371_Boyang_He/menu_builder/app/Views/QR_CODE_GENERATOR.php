<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QR Code Generator</title>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= base_url('css/QR_CODE.css'); ?>">
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="#">Coffee Shop</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav">
              <li class="nav-item">
                  <a class="nav-link" href="<?= base_url(); ?>">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Menu
                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <a class="dropdown-item" href="<?= base_url('/Menu_Page'); ?>">Menu List</a>
                      <a class="dropdown-item" href="<?= base_url('/Management'); ?>">Management Page</a>
                      <a class="dropdown-item active" href="<?= base_url('/QR_Generator'); ?>">QR Code Generator</a>
                  </div>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="<?= base_url('Log_In'); ?>">Log In</a>
              </li>
          </ul>
      </div>
</nav>

<div class="content">
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <label for="numberOfQRCodes">Number of QR Codes:</label>
                <input id="numberOfQRCodes" type="number" value="1" min="1" class="form-control mb-3"/>
                <button id="generate" class="btn btn-primary mb-3">Generate QR Codes</button>
            </div>
        </div>
        <div id="qrcode" class="row"></div>
    </div>
</div>

<!-- Footer -->
<footer class="text-light bg-dark pt-4 pb-2">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h5>Contact Us</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light">Our Address</a></li>
                    <li><a href="#" class="text-light">Email Us</a></li>
                    <li><a href="#" class="text-light">Phone</a></li>
                </ul>
            </div>
            <div class="col-sm-6">
                <h5>Follow Us</h5>
                <a href="#" class="text-light mr-2"><i class="fab fa-facebook"></i></a>
                <a href="#" class="text-light mr-2"><i the "fab fa-twitter"></i></a>
                <a href="#" class="text-light mr-2"><i class="fab fa-instagram"></i></a>
                <a href="#" class="text-light"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap JS and its dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/qrcodejs/qrcode.min.js"></script>
<!-- I admit using ChatGpt to create the following codes to help me generate the follwing methods -->
<script>
// Function to generate QR code and add table entry
function addTableAndGenerateQR() {
    var numberOfQRCodes = document.getElementById('numberOfQRCodes').value;
    console.log("Sending request for", numberOfQRCodes, "QR codes.");
    $.ajax({
        url: '<?= base_url('generate_tables_and_qrcodes'); ?>',
        type: 'POST',
        data: { numberOfTables: numberOfQRCodes },
        success: function(response) {
            console.log("Received response:", response);
            var data = response;  // If response is already an object, no need to parse it
            if (typeof response === 'string') {  // Safely handling the data if it's in string format
                data = JSON.parse(response);
            }
            console.log("Parsed data:", data);
            var qrContainer = document.getElementById('qrcode');
            qrContainer.innerHTML = '';
            data.qrCodes.forEach(function(code) {
                console.log("Processing QR code for table", code.tableNumber);
                var colDiv = document.createElement('div');
                colDiv.className = 'col-md-4 qrcode-item';
                colDiv.innerHTML = `<div class="d-flex flex-column align-items-center">
                                      <div>Table Number: ${code.tableNumber}</div>
                                      <div id="qr-${code.tableNumber}"></div>
                                    </div>`;
                qrContainer.appendChild(colDiv);

                new QRCode(document.getElementById(`qr-${code.tableNumber}`), {
                    text: code.qrCodeData,
                    width: 160,
                    height: 160
                });
            });
        },
        error: function(xhr, status, error) {
            console.error("Error on AJAX request:", status, error);
            alert('Error communicating with the server');
        }
    });
}


// Event listener
document.getElementById('generate').addEventListener('click', addTableAndGenerateQR);
</script>
</body>
</html>
